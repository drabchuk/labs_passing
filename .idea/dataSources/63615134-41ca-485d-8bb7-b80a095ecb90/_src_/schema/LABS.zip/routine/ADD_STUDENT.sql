create PROCEDURE        "ADD_STUDENT" 
(
  EMAIL IN VARCHAR2
,  PASS IN VARCHAR2
, FULL_NAME IN VARCHAR2  
, STD_GROUP_CHIFER IN VARCHAR2  
) AS

BEGIN
  set transaction isolation level serializable;
  
  if not exists(select * from student where student.email = email) then
    if exists(select * from std_group where std_group.chifer = std_group_chifer) then
      INSERT INTO student VALUES (email, pass, full_name, std_group_chifer);
    end if;
  end if;
  commit;
END ADD_STUDENT;