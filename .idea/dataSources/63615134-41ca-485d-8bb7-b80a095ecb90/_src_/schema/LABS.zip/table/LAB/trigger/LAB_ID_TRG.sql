create trigger LAB_ID_TRG
	before insert
	on LAB
	for each row
BEGIN
  SELECT lab_id_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;